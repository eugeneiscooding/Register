//
//  Home.swift
//  OTP
//
//  Created by Kavsoft on 18/01/20.
//  Copyright © 2020 Kavsoft. All rights reserved.
//

import SwiftUI
import Firebase

struct Home : View {
    
    var body : some View{
        
        VStack{
            
            Text("Welcome \(UserDefaults.standard.value(forKey: "UserName") as! String)")
            
            Button(action: {
                
                try! Auth.auth().signOut()
                
                UserDefaults.standard.set(false, forKey: "status")
                
                NotificationCenter.default.post(name: NSNotification.Name("statusChange"), object: nil)
                
            }) {
                
                Text("Logout")
            }
        }
    }
}

